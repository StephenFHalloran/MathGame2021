# MathGame2021
Game in Godot for practicing basic math.  
Not much more to process
